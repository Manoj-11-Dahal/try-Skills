---
name: skill-authoring-and-maintenance
description: "Use when creating or revising a reusable agent skill for a recurring workflow to define a narrow trigger, expected inputs, ordered procedure, safety constraints, outputs, and acceptance checks; keep prose concise, separate supporting references, validate metadata and links, and check source licenses before reusing content. Trigger when instructions are repeatedly re-explained or a workflow needs consistent execution."
---

# Skill Authoring and Maintenance

## Overview

This skill applies when creating or revising a reusable agent skill for a recurring workflow. Its intended outcome is to define a narrow trigger, expected inputs, ordered procedure, safety constraints, outputs, and acceptance checks; keep prose concise, separate supporting references, validate metadata and links, and check source licenses before reusing content.

## When to Use

### Preserved source section: When to Use

Use when a repeated task would benefit from reusable instructions, an existing skill has weak triggers or unclear steps, or a skill needs maintenance after tool, policy, or platform changes.

## Trigger Examples

Not specified in source skill content; no sample trigger phrases were provided.

## Scope

**Does:** Follow the task boundary stated under When to Use and the procedure below.

**Does not:** See the preserved source boundaries below and under Stop Conditions.

### Source boundary statements from: Procedure

4. **Specify inputs and boundaries.** Identify required context, tools, permissions, trust boundaries, and approval gates. Do not imply capabilities the agent does not have.

### Source boundary statements from: Maintenance Rules

- Do not add metadata or dependencies unsupported by the target host.

## Inputs

**Required:** See the preserved source input guidance below.

**Optional:** Not specified in source skill.

**If information is missing:** Not specified in source skill.

### Preserved source section: Inputs

- The recurring task, users, context, and observed failure modes.
- Trigger phrases or conditions that distinguish when the skill applies.
- Required tools, data, constraints, acceptance criteria, and examples.
- Existing skills, repository conventions, source provenance, and license terms.

## Instructions

### Preserved source section: Procedure

1. **Confirm a real repeated need.** Identify the task the skill will improve and the cost of not having reusable guidance.
2. **Choose a narrow scope.** State what the skill does, when it applies, and when it does not. Split unrelated workflows rather than creating a broad catch-all.
3. **Write trigger metadata.** Use a descriptive, stable name and a description that states both capability and activation conditions in vocabulary users actually use.
4. **Specify inputs and boundaries.** Identify required context, tools, permissions, trust boundaries, and approval gates. Do not imply capabilities the agent does not have.
5. **Write an ordered procedure.** Make each step actionable and evidence-oriented. Include stop, escalation, and recovery paths for likely failures.
6. **Define output and acceptance.** Say what artifact or report is expected and how another person or tool can verify it.
7. **Add examples only when useful.** Use small examples that clarify ambiguous decisions; avoid duplicating the whole procedure in examples.
8. **Separate references and assets.** Keep the main skill focused. Link only to existing support files and avoid deep chains of references.
9. **Check provenance and licensing.** Write original instructions where possible. Verify permission before copying upstream material; if permission is absent or unclear, record the source and reason instead of mirroring it.
10. **Validate and maintain.** Check metadata, directory/name match, triggers, readability, size, links, tests, and real activations. Reassess stale tools, links, assumptions, and safety rules after changes.

## Decision Rules

Not specified in source skill.

## Tools and Resources

**Use:** Not specified in source skill.

**Do not use:** Not specified in source skill.

**Fallback:** Not specified in source skill.

## Output Format

### Preserved source section: Output and Acceptance

Deliver a standalone skill with clear activation, inputs, procedure, output, and safety criteria, plus source notes for any external material. The skill is acceptable when its trigger is distinguishable from neighboring skills, its steps can be followed, its internal links work, and its claims and dependencies are current.

## Quality Standards

### Acceptance standards from source: Output and Acceptance

Deliver a standalone skill with clear activation, inputs, procedure, output, and safety criteria, plus source notes for any external material. The skill is acceptable when its trigger is distinguishable from neighboring skills, its steps can be followed, its internal links work, and its claims and dependencies are current.

## Validation Checklist

- [ ] Confirm the source-defined acceptance standard preserved under Quality Standards or Output Format is met.

## Edge Cases and Recovery

### Source edge/failure guidance from: Inputs

- The recurring task, users, context, and observed failure modes.

### Source edge/failure guidance from: Procedure

5. **Write an ordered procedure.** Make each step actionable and evidence-oriented. Include stop, escalation, and recovery paths for likely failures.

## Stop Conditions

### Source stop-related guidance from: Procedure

5. **Write an ordered procedure.** Make each step actionable and evidence-oriented. Include stop, escalation, and recovery paths for likely failures.

## Common Pitfalls

Not specified in source skill.

## Examples

**Example input:** Not specified in source skill.

**Example output:** Not specified in source skill.

**Anti-example:** Not specified in source skill.

**Why it fails:** Not specified in source skill.

## Test Cases

Not specified in source skill; no runnable test cases were supplied.

## Success Criteria

### Success criteria from source: Output and Acceptance

Deliver a standalone skill with clear activation, inputs, procedure, output, and safety criteria, plus source notes for any external material. The skill is acceptable when its trigger is distinguishable from neighboring skills, its steps can be followed, its internal links work, and its claims and dependencies are current.

## Related Skills

Not specified in source skill.

## Maintenance

**Owner:** Not specified in source skill.

**Version:** Not specified in source skill.

**Last reviewed:** Not specified in source skill.

**Review trigger:** Not specified in source skill.

### Preserved source section: Maintenance Rules

- Prefer small, reviewable updates over rewriting working guidance without evidence.
- Do not add metadata or dependencies unsupported by the target host.
- Preserve working user content and existing skills; use an explicit update process for replacements.
- Keep evaluation cases aligned with the actual trigger and acceptance criteria.
