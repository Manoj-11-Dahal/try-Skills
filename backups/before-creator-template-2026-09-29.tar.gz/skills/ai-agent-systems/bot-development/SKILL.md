---
name: bot-development
description: "Use when building or changing an automated bot that responds to messages, events, schedules, or platform APIs to define authorized actions, user consent, scopes, idempotency, rate limits, and failure behavior before connecting a live account. Trigger for chat, community, workflow, monitoring, or platform automation bots."
---

# Bot Development

## Overview

This skill applies when building or changing an automated bot that responds to messages, events, schedules, or platform APIs. Its intended outcome is to define authorized actions, user consent, scopes, idempotency, rate limits, and failure behavior before connecting a live account.

## When to Use

### Preserved source section: When to Use

Use for a software agent that acts through a platform account or reacts to incoming events. Distinguish read-only assistance from posting, moderation, messaging, purchases, or other externally visible actions.

## Trigger Examples

Not specified in source skill content; no sample trigger phrases were provided.

## Scope

**Does:** Follow the task boundary stated under When to Use and the procedure below.

**Does not:** See the preserved source boundaries below and under Stop Conditions.

### Source boundary statements from: Procedure

4. **Respect platform controls.** Use official APIs, minimum scopes, documented rate limits, backoff for transient failures, and an explicit stop mechanism. Do not bypass access controls, anti-abuse limits, or user privacy settings.

### Source boundary statements from: Output and Acceptance

Document event coverage, permission scopes, write actions, idempotency behavior, rate limits, data retention, test evidence, and the live-activation gate. Accept when duplicate events do not duplicate effects, denied actions fail closed, and the bot's authority matches the approved scope.

## Inputs

**Required:** See the preserved source input guidance below.

**Optional:** Not specified in source skill.

**If information is missing:** Not specified in source skill.

### Preserved source section: Inputs

- Target platform and its official API, event, and policy documentation.
- User roles, event types, commands, permissions, and expected bot behavior.
- Required scopes, secret storage, data retention, rate limits, and confirmation rules.

## Instructions

### Preserved source section: Procedure

1. **Define behavior and authority.** List triggers, allowed actions, prohibited actions, and whether a human must confirm each write. Keep read and write permissions separate.
2. **Build a local handler first.** Normalize one event type, validate its schema, produce a deterministic decision, and test the response without a live account.
3. **Handle retries safely.** Use event IDs or idempotency keys, acknowledge only after durable processing, and prevent duplicate posts or repeated side effects.
4. **Respect platform controls.** Use official APIs, minimum scopes, documented rate limits, backoff for transient failures, and an explicit stop mechanism. Do not bypass access controls, anti-abuse limits, or user privacy settings.
5. **Protect user data.** Minimize stored content, redact logs, limit retention, and restrict who can inspect conversations or identifiers.
6. **Test policy and failure cases.** Cover malformed events, duplicate delivery, permission denial, rate limiting, service outage, unsafe content, and human approval timeout.
7. **Stage activation.** Start in a sandbox or private test channel, observe logs and rate behavior, then request separate approval before enabling live writes.

## Decision Rules

Not specified in source skill.

## Tools and Resources

**Use:** Not specified in source skill.

**Do not use:** Not specified in source skill.

**Fallback:** Not specified in source skill.

## Output Format

### Preserved source section: Output and Acceptance

Document event coverage, permission scopes, write actions, idempotency behavior, rate limits, data retention, test evidence, and the live-activation gate. Accept when duplicate events do not duplicate effects, denied actions fail closed, and the bot's authority matches the approved scope.

## Quality Standards

### Acceptance standards from source: Output and Acceptance

Document event coverage, permission scopes, write actions, idempotency behavior, rate limits, data retention, test evidence, and the live-activation gate. Accept when duplicate events do not duplicate effects, denied actions fail closed, and the bot's authority matches the approved scope.

## Validation Checklist

- [ ] Confirm the source-defined acceptance standard preserved under Quality Standards or Output Format is met.

## Edge Cases and Recovery

### Source edge/failure guidance from: Procedure

3. **Handle retries safely.** Use event IDs or idempotency keys, acknowledge only after durable processing, and prevent duplicate posts or repeated side effects.
4. **Respect platform controls.** Use official APIs, minimum scopes, documented rate limits, backoff for transient failures, and an explicit stop mechanism. Do not bypass access controls, anti-abuse limits, or user privacy settings.
6. **Test policy and failure cases.** Cover malformed events, duplicate delivery, permission denial, rate limiting, service outage, unsafe content, and human approval timeout.

### Source edge/failure guidance from: Output and Acceptance

Document event coverage, permission scopes, write actions, idempotency behavior, rate limits, data retention, test evidence, and the live-activation gate. Accept when duplicate events do not duplicate effects, denied actions fail closed, and the bot's authority matches the approved scope.

## Stop Conditions

### Source stop-related guidance from: Procedure

4. **Respect platform controls.** Use official APIs, minimum scopes, documented rate limits, backoff for transient failures, and an explicit stop mechanism. Do not bypass access controls, anti-abuse limits, or user privacy settings.

## Common Pitfalls

Not specified in source skill.

## Examples

**Example input:** Not specified in source skill.

**Example output:** Not specified in source skill.

**Anti-example:** Not specified in source skill.

**Why it fails:** Not specified in source skill.

## Test Cases

Not specified in source skill; no runnable test cases were supplied.

## Success Criteria

### Success criteria from source: Output and Acceptance

Document event coverage, permission scopes, write actions, idempotency behavior, rate limits, data retention, test evidence, and the live-activation gate. Accept when duplicate events do not duplicate effects, denied actions fail closed, and the bot's authority matches the approved scope.

## Related Skills

Not specified in source skill.

## Maintenance

**Owner:** Not specified in source skill.

**Version:** Not specified in source skill.

**Last reviewed:** Not specified in source skill.

**Review trigger:** Not specified in source skill.
