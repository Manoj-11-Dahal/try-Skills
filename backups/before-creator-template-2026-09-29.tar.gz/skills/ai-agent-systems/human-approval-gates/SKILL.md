---
name: human-approval-gates
description: "Use when a proposed agent action can publish, delete, purchase, send, deploy, change access, expose data, or otherwise cause material external effects to classify risk, request specific human approval before gated actions, show exact scope, and verify the result. Trigger before irreversible, costly, sensitive, or third-party-impacting operations."
---

# Human Approval Gates

## Overview

This skill applies when a proposed agent action can publish, delete, purchase, send, deploy, change access, expose data, or otherwise cause material external effects. Its intended outcome is to classify risk, request specific human approval before gated actions, show exact scope, and verify the result.

## When to Use

### Preserved source section: When to Use

Use this skill before an action that is irreversible, expensive, sensitive, externally visible, or capable of affecting another person or system. Examples include deleting data, sending a message, making a purchase, publishing content, changing access, deploying to production, or sharing private information.

## Trigger Examples

Not specified in source skill content; no sample trigger phrases were provided.

## Scope

**Does:** Follow the task boundary stated under When to Use and the procedure below.

**Does not:** See the preserved source boundaries below and under Stop Conditions.

### Source boundary statements from: Procedure

4. **Request specific approval.** Ask the authorized person to approve that action. Do not infer approval from silence, an earlier unrelated approval, or a general request to complete the project.

## Inputs

**Required:** See the preserved source input guidance below.

**Optional:** Not specified in source skill.

**If information is missing:** Not specified in source skill.

### Preserved source section: Inputs

- The exact proposed action and target.
- The data or resources affected and the likely consequences.
- Reversibility, blast radius, and available rollback method.
- Existing user authorization and its scope.
- The verification evidence available after the action.

## Instructions

### Preserved source section: Procedure

1. **Classify risk.** Assess impact, reversibility, privacy, financial cost, external visibility, and scope. Treat uncertainty as a reason to narrow the action or ask.
2. **Separate preparation from execution.** Draft, inspect, validate, and preview without crossing the gate. A prepared draft is not permission to send or publish it.
3. **Define the approval request.** Show the action, exact target, relevant content or amount, timing, consequence, and rollback option in concise language.
4. **Request specific approval.** Ask the authorized person to approve that action. Do not infer approval from silence, an earlier unrelated approval, or a general request to complete the project.
5. **Re-check scope.** Before executing, confirm the approved target and parameters still match the current plan. Ask again if the action materially changed.
6. **Execute narrowly.** Perform only the approved operation. Avoid bundling additional changes under the same approval.
7. **Verify and report.** Inspect the resulting state and report whether it succeeded, failed, or remains uncertain.

## Decision Rules

Not specified in source skill.

## Tools and Resources

**Use:** Not specified in source skill.

**Do not use:** Not specified in source skill.

**Fallback:** Not specified in source skill.

## Output Format

### Preserved source section: Output and Acceptance

For gated work, provide a clear approval request and wait before execution. After approval, record the approved scope and the verified result. The gate is satisfied only by explicit authorization from the right person for the exact action; the action is complete only when post-action evidence confirms the expected state.

## Quality Standards

### Acceptance standards from source: Output and Acceptance

For gated work, provide a clear approval request and wait before execution. After approval, record the approved scope and the verified result. The gate is satisfied only by explicit authorization from the right person for the exact action; the action is complete only when post-action evidence confirms the expected state.

## Validation Checklist

- [ ] Confirm the source-defined acceptance standard preserved under Quality Standards or Output Format is met.

## Edge Cases and Recovery

### Source edge/failure guidance from: Procedure

7. **Verify and report.** Inspect the resulting state and report whether it succeeded, failed, or remains uncertain.

## Stop Conditions

### Preserved source section: Stop Conditions

Stop and ask when the target is ambiguous, the approval source is unclear, the risk exceeds the user's stated scope, or the operation cannot be rolled back safely. If a platform's tool call itself creates an external side effect, do not use it for a supposedly harmless preview.

## Common Pitfalls

Not specified in source skill.

## Examples

**Example input:** Not specified in source skill.

**Example output:** Not specified in source skill.

**Anti-example:** Not specified in source skill.

**Why it fails:** Not specified in source skill.

## Test Cases

Not specified in source skill; no runnable test cases were supplied.

## Success Criteria

### Success criteria from source: Output and Acceptance

For gated work, provide a clear approval request and wait before execution. After approval, record the approved scope and the verified result. The gate is satisfied only by explicit authorization from the right person for the exact action; the action is complete only when post-action evidence confirms the expected state.

## Related Skills

Not specified in source skill.

## Maintenance

**Owner:** Not specified in source skill.

**Version:** Not specified in source skill.

**Last reviewed:** Not specified in source skill.

**Review trigger:** Not specified in source skill.
