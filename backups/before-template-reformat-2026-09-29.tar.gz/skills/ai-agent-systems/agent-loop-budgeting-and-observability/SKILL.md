---
name: agent-loop-budgeting-and-observability
description: "Use when an agent loop can consume variable time, tool calls, money, tokens, or external quota. Set explicit limits and progress signals, monitor them per iteration, detect churn or plateau, and stop or ask before crossing budgets. Trigger for unattended, recurring, multi-agent, or open-ended tasks where cost or runaway behavior matters."
---

# Agent Loop Budgeting and Observability

## When to Use

Use before starting unattended, recurring, multi-agent, or open-ended work whose time, tool usage, financial cost, or external quota could grow unpredictably.

## Inputs

- Objective, artifact, feedback signal, and success threshold.
- Available budget for time, iterations, tool calls, tokens, money, or API quota.
- Progress indicators and logs that can be collected safely.
- Conditions that require a pause, approval, or escalation.

## Procedure

1. **Set hard limits.** Define maximum elapsed time, iterations, tool calls, and spend where measurable. Add a safety margin for cleanup and verification.
2. **Choose leading indicators.** Track useful changes per iteration, not just activity. Examples include passing checks, verified claims, completed subtasks, or artifact quality against a fixed rubric.
3. **Instrument each cycle.** Record start/end time, action, result, budget consumed, progress signal, and remaining allowance. Avoid logging secrets or unnecessary personal data.
4. **Check for churn.** Detect repeated errors, no-op edits, unchanged scores, growing scope, duplicated agent work, or rising cost without corresponding progress.
5. **Adjust safely.** Reduce parallelism, narrow scope, lower frequency, or switch to a cheaper diagnostic when the progress signal stalls.
6. **Warn before thresholds.** Notify the user or controller before a soft budget is reached. Stop before a hard budget or external quota is exceeded.
7. **Reserve exit capacity.** Keep enough budget to save state, run final checks, undo unsafe changes, and report accurately.
8. **Review after the run.** Compare expected and actual cost, time, and progress. Tune future limits only with evidence; do not weaken acceptance checks just to fit a budget.

## Output and Acceptance

Return a budget contract, progress metrics, alert thresholds, hard stop rules, and a short run summary showing consumption and verified progress. The loop is acceptable when it can halt before exhaustion and leave the artifact in a safe, inspectable state.

## Stop Conditions

- Stop at the hard time, cost, iteration, or tool-call limit.
- Stop early when the objective is verified or the progress signal plateaus beyond the agreed threshold.
- Pause for approval if scope or spending changes materially.
- Never hide a budget overrun or report activity as progress without evidence.
