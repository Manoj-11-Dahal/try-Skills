---
name: state-and-handoff
description: "Use when work spans sessions, runs, agents, or context windows and progress must survive handoffs. Record the objective, current state, decisions, evidence, unresolved risks, next action, and stopping rule in a durable artifact; verify freshness before resuming. Trigger for asynchronous, unattended, delegated, or long-running agent workflows."
---

# State and Handoff

## When to Use

Use this skill whenever the work may outlive the current turn, be delegated to another agent, resume after a failure, or depend on information that will not reliably remain in conversational context.

## Inputs

- The current objective and success condition.
- The durable state location and any access or privacy constraints.
- Completed actions, artifacts, observations, and decisions.
- Pending actions, open questions, risks, and resource limits.

## Procedure

1. **Read before resuming.** Load the existing checkpoint and verify that it belongs to the current task, target, and version of the artifact.
2. **Separate fact from intent.** Mark completed work with evidence. Keep proposed actions, assumptions, and unresolved questions in separate fields.
3. **Write a compact checkpoint.** Include objective, scope, current artifact locations, completed steps, verification results, decisions, blockers, remaining budget, next action, and stop conditions.
4. **Keep a trace.** Append consequential actions and observations to an ordered ledger. Do not rewrite history to make an unsuccessful step appear successful.
5. **Protect sensitive data.** Store only the minimum information needed. Redact secrets, tokens, personal data, and private payloads from summaries and logs.
6. **Update atomically.** Use a temporary file or transactional update when possible, then verify the saved checkpoint can be read back.
7. **Handoff explicitly.** Tell the next agent what is safe to do, what requires approval, what must not be repeated, and which checks remain.
8. **Revalidate freshness.** Before acting on an old checkpoint, inspect the target state for intervening changes and revise the plan if necessary.

## Output and Acceptance

Produce a concise durable checkpoint and a short handoff summary. The handoff is acceptable when another agent can identify the current objective, verified state, unresolved risks, next safe step, required approvals, and exact stopping conditions without relying on hidden conversational context.

## Checkpoint Template

Use a project-appropriate file with fields equivalent to:

- Objective and acceptance criteria
- Current artifact or target state
- Completed actions and evidence
- Decisions and assumptions
- Pending questions and risks
- Budget remaining
- Next safe action
- Human approvals required
- Stop conditions
