---
name: continuous-learning-and-pattern-curation
description: "Use when a user asks to preserve a lesson, repeated correction, or successful workflow as reusable guidance for future tasks. Turn observed evidence into a small, scoped candidate pattern, distinguish confidence from fact, and obtain approval before persistent or cross-project storage. Trigger for explicit learning, memory curation, or pattern promotion requests."
---

# Continuous Learning and Pattern Curation

## When to Use

Use when the user requests a durable lesson or a recurring behavior is worth proposing for future sessions. Do not silently convert ordinary conversation, personal data, or one-off assumptions into persistent memory.

## Inputs

- The observed correction, repeated workflow, or outcome and its source context.
- The intended scope: one task, one repository, a user preference, or a reusable general practice.
- The storage location, retention policy, sharing boundary, and user approval requirements.

## Procedure

1. **Collect evidence narrowly.** Quote or summarize only relevant observations. Distinguish direct user instruction from inferred preference and from a one-time exception.
2. **Propose one atomic pattern.** State a trigger and a single action. Include an example or counterexample only if needed to disambiguate the behavior.
3. **Assess repeatability and confidence.** Look for independent repetitions or explicit confirmation. Mark tentative patterns as tentative; do not turn a guess into a hard rule.
4. **Choose the smallest scope.** Default project-specific conventions to that project. Promote a pattern globally only when it is genuinely general, useful in multiple contexts, and approved for that scope.
5. **Check privacy and safety.** Remove secrets, personal data, customer content, and proprietary details unless retention is explicitly authorized and necessary. Do not store raw conversation logs as a shortcut.
6. **Ask before persistence.** Show the proposed text, destination, scope, and retention effect. Write only after required approval; preserve unrelated memory and include provenance or review date where supported.
7. **Review and retire.** Re-check patterns when contradicted, stale, or no longer useful. Lower confidence, narrow scope, or remove them through the storage system's approved process.

## Output and Acceptance

Return the candidate pattern, evidence basis, confidence, scope, proposed destination, and approval status. A learning is accepted only when it is useful, non-sensitive, scoped correctly, user-approved where required, and stored without changing unrelated memory.

## Guardrails

- Do not imply that a platform supports automatic memory or observation unless the current tools actually provide it.
- Never persist secrets or hidden user information.
- Do not treat one correction as universal unless the user explicitly says it is a standing preference.
