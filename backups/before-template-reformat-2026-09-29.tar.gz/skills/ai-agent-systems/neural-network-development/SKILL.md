---
name: neural-network-development
description: "Use when implementing a neural-network model, training loop, inference component, or learning algorithm. Define tensor shapes, data provenance, objective, and evaluation before training; verify numerical behavior on small reproducible cases before using larger or sensitive datasets. Trigger for architecture, gradient, optimizer, or model-serving work."
---

# Neural Network Development

## When to Use

Use for model computation and training workflows. Distinguish a learning exercise from a validated model intended to influence real decisions.

## Inputs

- Task, model inputs and outputs, tensor shapes, and intended use.
- Dataset provenance, consent, license, split policy, and sensitivity.
- Compute budget, seed policy, evaluation metrics, and deployment constraints.

## Procedure

1. **Establish a baseline.** Define a simple model or non-neural baseline, metrics, and held-out evaluation split before tuning.
2. **Make shapes explicit.** Document batch, sequence, channel, and feature dimensions. Validate shapes and data types at module boundaries.
3. **Test the numerical core.** Check forward outputs, loss behavior, gradients, optimizer updates, and finite values on tiny hand-checkable examples. Use gradient checks for custom derivatives.
4. **Build the data path.** Prevent train/test leakage, record preprocessing, handle missing or imbalanced labels, and keep sensitive data out of logs and checkpoints unless explicitly authorized.
5. **Train reproducibly.** Set and record random seeds, data versions, model configuration, compute settings, checkpoints, and stopping criteria. Track more than one metric when tradeoffs matter.
6. **Evaluate generalization and risk.** Report performance on held-out data, relevant slices, calibration or uncertainty where needed, and known limitations. Do not optimize only the training score.
7. **Gate deployment separately.** Validate latency, resource use, rollback, monitoring, privacy, and human oversight for the actual intended use.

## Safety and Acceptance

Do not present benchmark success as proof of real-world safety or fairness. Obtain domain review for high-impact use. Accept a prototype when computations are numerically sound, results are reproducible, data handling is documented, and evaluation matches the stated task.
