---
name: failure-recovery-and-replanning
description: "Use when a tool call, test, or action fails, returns ambiguous output, or does not improve the artifact. Diagnose the failure, preserve known-good state, change the next attempt, bound retries, and escalate when evidence remains insufficient. Trigger for recovery, replanning, partial completion, and repeated errors in autonomous or multi-turn workflows."
---

# Failure Recovery and Replanning

## When to Use

Use this skill when an action fails, the observed result differs from the expected result, the agent repeats itself without progress, or a long-running task becomes blocked. It applies to tool errors, test failures, environmental limits, and incorrect assumptions.

## Inputs

- The last known-good artifact or state.
- The failed action, exact tool output, logs, and relevant environment facts.
- The original objective, acceptance checks, and remaining budget.
- Any side effects that may have occurred despite an error response.

## Procedure

1. **Freeze risky changes.** Do not immediately retry a write or external operation if its first attempt may have partially succeeded.
2. **Preserve evidence.** Save the error, command, inputs, and current state. Keep a recoverable copy or rollback path for important artifacts.
3. **Classify the failure.** Distinguish invalid input, permission denial, missing dependency, environment or network failure, tool outage, logic defect, and a wrong objective assumption.
4. **Check for partial effects.** Query the target system or inspect the filesystem before deciding what to retry.
5. **Form a changed hypothesis.** State what is believed to have failed and what evidence would distinguish that cause from alternatives.
6. **Choose a bounded repair.** Change one relevant variable, reduce scope, or use a safer alternative. Do not repeat an identical failing action without new information.
7. **Set a retry budget.** Limit retries by count, time, and cost. After the limit, stop and ask for help or report the blocker.
8. **Re-verify.** Run the original acceptance check and any regression checks. Confirm that recovery did not damage previously working state.
9. **Update durable state.** Record the root cause, attempted repair, result, and next step for later turns.

## Output and Acceptance

Provide a concise incident note with the failure class, evidence, partial-effect check, repair attempted, retry count, and verification result. Recovery is acceptable only when the target behavior passes its acceptance check and the known-good state remains intact; otherwise report partial or blocked status.

## Retry Guardrails

- Use exponential backoff only for transient failures where retrying is safe.
- Do not retry authorization failures as if they were network errors.
- Do not use repeated retries to conceal missing permissions or missing user input.
- If the same hypothesis fails twice, stop and choose a materially different diagnostic step.
