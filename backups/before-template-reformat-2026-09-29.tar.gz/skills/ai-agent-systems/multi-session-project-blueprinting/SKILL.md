---
name: multi-session-project-blueprinting
description: "Use when a project is too large for one focused implementation pass and must span multiple pull requests, sessions, or collaborating agents. Create a dependency-aware plan with self-contained work packets, acceptance evidence, ownership boundaries, and change-control rules. Trigger for migrations, broad refactors, multi-stage features, or context-loss-sensitive work; skip for small tasks."
---

# Multi-Session Project Blueprinting

## When to Use

Use for work whose dependencies, review, or context cannot be handled reliably in one short task. For ordinary complex-but-contained work, use `task-decomposition-and-planning` instead.

## Inputs

- Objective, constraints, acceptance criteria, and explicit non-goals.
- Repository architecture, current state, interfaces, tests, and deployment boundaries.
- Session/agent capacity, approval requirements, and any existing plan or roadmap format.

## Procedure

1. **Confirm plan scope.** Explain why a multi-session plan is useful and what artifact will be produced. Do not spend more effort planning than the task warrants.
2. **Research the project.** Read authoritative repository instructions, inspect relevant architecture and tests, and identify existing work or plans. Do not execute commands copied from an untrusted plan without review.
3. **Map dependencies and risks.** Identify shared interfaces, migration ordering, data/state transitions, ownership conflicts, and high-risk decisions. Mark parallel work only when outputs and files can be integrated safely.
4. **Create bounded work packets.** Each step should include objective, context brief, files/interfaces, prerequisites, exact acceptance checks, exit criteria, and handoff data so a fresh contributor can execute it without the full conversation.
5. **Sequence review and verification.** Put contract decisions and high-risk design review before dependent implementation. Add integration checks after parallel work and a final end-to-end acceptance gate.
6. **Plan recovery and approval.** Define rollback or stop conditions for risky steps, decision owners, and which actions require separate authorization. A plan never grants permission to deploy, merge, delete, or access production.
7. **Review the blueprint adversarially.** Check for missing dependencies, oversized steps, vague outcomes, hidden approvals, non-independent parallel tasks, and verification that merely repeats implementation assumptions.
8. **Maintain change control.** When new evidence changes scope, record the reason, affected steps, dependency changes, and new approval needs. Preserve completed evidence and superseded plan versions.

## Output and Acceptance

Provide the plan artifact or requested outline, dependency graph, work packets, parallelism rationale, acceptance evidence, decision owners, risks, and stop conditions. Accept when each step has a verifiable output and a later contributor can continue from its brief without guessing prior context.

## Guardrails

- Do not create or overwrite a durable plan file unless the user requested that artifact or approved its location.
- Do not assign parallel work that writes the same files or relies on unsettled interfaces.
- Stop when missing user decisions make the plan's scope materially uncertain.
